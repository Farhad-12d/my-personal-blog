export const metadata = { title: "About" };

export default function AboutPage() {
  return (
    <div className="mx-auto max-w-2xl px-6 py-16">
      <h1 className="font-serif text-3xl italic">About</h1>
      <div className="prose prose-lg mt-8 max-w-none">
        <p>
          This is where a short bio goes — who you are, what you&apos;re
          working on, and why you&apos;re writing. Edit this page at
          <code> app/about/page.tsx</code>.
        </p>
      </div>
    </div>
  );
}
