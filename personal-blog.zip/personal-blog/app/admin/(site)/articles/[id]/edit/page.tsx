import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import ArticleEditor from "@/components/admin/ArticleEditor";

type Props = { params: { id: string } };

export default async function EditArticlePage({ params }: Props) {
  const [article, categories] = await Promise.all([
    db.article.findUnique({
      where: { id: params.id },
      include: { tags: { include: { tag: true } } },
    }),
    db.category.findMany({ orderBy: { name: "asc" } }),
  ]);

  if (!article) notFound();

  return (
    <div>
      <h1 className="font-serif text-2xl italic">Edit article</h1>
      <div className="mt-6">
        <ArticleEditor
          categories={categories}
          initial={{
            id: article.id,
            title: article.title,
            slug: article.slug,
            excerpt: article.excerpt ?? "",
            content: article.content,
            featuredImage: article.featuredImage ?? "",
            status: article.status,
            categoryId: article.categoryId ?? "",
            tagNames: article.tags.map((t) => t.tag.name).join(", "),
          }}
        />
      </div>
    </div>
  );
}
