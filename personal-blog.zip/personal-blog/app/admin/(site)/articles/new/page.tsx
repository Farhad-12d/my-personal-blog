import { db } from "@/lib/db";
import ArticleEditor from "@/components/admin/ArticleEditor";

export default async function NewArticlePage() {
  const categories = await db.category.findMany({ orderBy: { name: "asc" } });

  return (
    <div>
      <h1 className="font-serif text-2xl italic">New article</h1>
      <div className="mt-6">
        <ArticleEditor categories={categories} />
      </div>
    </div>
  );
}
