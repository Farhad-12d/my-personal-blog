import Link from "next/link";
import { db } from "@/lib/db";
import Button from "@/components/ui/Button";
import DeleteArticleButton from "@/components/admin/DeleteArticleButton";
import { formatDate } from "@/lib/utils";

export default async function AdminArticlesPage() {
  const articles = await db.article.findMany({
    orderBy: { updatedAt: "desc" },
    include: { category: true },
  });

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="font-serif text-2xl italic">Articles</h1>
        <Link href="/admin/articles/new">
          <Button>New article</Button>
        </Link>
      </div>

      {articles.length === 0 ? (
        <p className="mt-8 text-muted-light dark:text-muted">
          No articles yet — create your first one.
        </p>
      ) : (
        <div className="mt-6 divide-y divide-line-light dark:divide-line">
          {articles.map((article) => (
            <div
              key={article.id}
              className="flex items-center justify-between gap-4 py-4"
            >
              <div className="min-w-0">
                <Link
                  href={`/admin/articles/${article.id}/edit`}
                  className="truncate font-serif text-lg hover:text-brass"
                >
                  {article.title}
                </Link>
                <p className="mt-1 text-sm text-muted-light dark:text-muted">
                  {article.status}
                  {article.category ? ` · ${article.category.name}` : ""} · updated{" "}
                  {formatDate(article.updatedAt)}
                </p>
              </div>
              <div className="flex shrink-0 items-center gap-4">
                <Link
                  href={`/admin/articles/${article.id}/edit`}
                  className="text-sm hover:text-brass"
                >
                  Edit
                </Link>
                <DeleteArticleButton id={article.id} title={article.title} />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
