import { db } from "@/lib/db";
import CommentActions from "@/components/admin/CommentActions";
import { formatDate } from "@/lib/utils";

export default async function AdminCommentsPage() {
  const comments = await db.comment.findMany({
    orderBy: { createdAt: "desc" },
    include: { article: { select: { title: true, slug: true } } },
  });

  return (
    <div>
      <h1 className="font-serif text-2xl italic">Comments</h1>

      {comments.length === 0 ? (
        <p className="mt-8 text-muted-light dark:text-muted">No comments yet.</p>
      ) : (
        <div className="mt-6 divide-y divide-line-light dark:divide-line">
          {comments.map((comment) => (
            <div key={comment.id} className="flex items-start justify-between gap-4 py-4">
              <div className="min-w-0">
                <p className="text-sm">
                  <span className="font-medium">{comment.authorName}</span>{" "}
                  <span className="text-muted-light dark:text-muted">
                    on {comment.article.title} · {formatDate(comment.createdAt)} ·{" "}
                    {comment.approved ? "approved" : "pending"}
                  </span>
                </p>
                <p className="mt-1 text-sm text-muted-light dark:text-muted">
                  {comment.content}
                </p>
              </div>
              <CommentActions id={comment.id} approved={comment.approved} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
