import Link from "next/link";
import LogoutButton from "@/components/admin/LogoutButton";

export default function AdminSiteLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="mx-auto max-w-5xl px-6 py-10">
      <div className="flex items-center justify-between border-b border-line-light pb-6 dark:border-line">
        <nav className="flex items-center gap-6 text-sm">
          <Link href="/admin" className="font-serif italic">
            Dashboard
          </Link>
          <Link href="/admin/articles" className="hover:text-brass">
            Articles
          </Link>
          <Link href="/admin/comments" className="hover:text-brass">
            Comments
          </Link>
          <Link href="/" className="text-muted-light hover:text-brass dark:text-muted">
            View site
          </Link>
        </nav>
        <LogoutButton />
      </div>
      <div className="pt-8">{children}</div>
    </div>
  );
}
