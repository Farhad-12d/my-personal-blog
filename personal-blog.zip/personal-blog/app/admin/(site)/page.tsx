import Link from "next/link";
import { db } from "@/lib/db";
import Button from "@/components/ui/Button";
import { formatDate } from "@/lib/utils";

export default async function AdminDashboard() {
  const [published, drafts, pendingComments, recent] = await Promise.all([
    db.article.count({ where: { status: "PUBLISHED" } }),
    db.article.count({ where: { status: "DRAFT" } }),
    db.comment.count({ where: { approved: false } }),
    db.article.findMany({
      orderBy: { updatedAt: "desc" },
      take: 5,
      select: { id: true, title: true, status: true, updatedAt: true },
    }),
  ]);

  const stats = [
    { label: "Published", value: published },
    { label: "Drafts", value: drafts },
    { label: "Comments to review", value: pendingComments },
  ];

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="font-serif text-2xl italic">Dashboard</h1>
        <Link href="/admin/articles/new">
          <Button>New article</Button>
        </Link>
      </div>

      <div className="mt-8 grid grid-cols-3 gap-6">
        {stats.map((stat) => (
          <div key={stat.label} className="border border-line-light p-4 dark:border-line">
            <p className="text-2xl font-medium">{stat.value}</p>
            <p className="mt-1 text-sm text-muted-light dark:text-muted">
              {stat.label}
            </p>
          </div>
        ))}
      </div>

      <div className="mt-12">
        <h2 className="font-serif text-lg italic">Recently edited</h2>
        <div className="mt-4 divide-y divide-line-light dark:divide-line">
          {recent.map((article) => (
            <Link
              key={article.id}
              href={`/admin/articles/${article.id}/edit`}
              className="flex items-center justify-between py-3 text-sm hover:text-brass"
            >
              <span>{article.title}</span>
              <span className="text-muted-light dark:text-muted">
                {article.status} · {formatDate(article.updatedAt)}
              </span>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
