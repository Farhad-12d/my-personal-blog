import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/session";
import { updateArticle, deleteArticle } from "@/lib/articles";
import { db } from "@/lib/db";

type Params = { params: { id: string } };

export async function GET(_request: NextRequest, { params }: Params) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const article = await db.article.findUnique({
    where: { id: params.id },
    include: { tags: { include: { tag: true } } },
  });
  if (!article) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json(article);
}

export async function PATCH(request: NextRequest, { params }: Params) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await request.json();
  const article = await updateArticle(params.id, body);
  return NextResponse.json(article);
}

export async function DELETE(_request: NextRequest, { params }: Params) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  await deleteArticle(params.id);
  return NextResponse.json({ ok: true });
}
