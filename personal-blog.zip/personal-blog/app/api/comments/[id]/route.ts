import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/session";
import { db } from "@/lib/db";

type Params = { params: { id: string } };

export async function PATCH(request: NextRequest, { params }: Params) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { approved } = await request.json();
  const comment = await db.comment.update({
    where: { id: params.id },
    data: { approved: Boolean(approved) },
  });
  return NextResponse.json(comment);
}

export async function DELETE(_request: NextRequest, { params }: Params) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  await db.comment.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
