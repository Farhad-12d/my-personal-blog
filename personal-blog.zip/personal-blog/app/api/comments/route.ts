import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function POST(request: NextRequest) {
  const { articleId, authorName, authorEmail, content } = await request.json();

  if (!articleId || !authorName || !authorEmail || !content) {
    return NextResponse.json({ error: "All fields are required" }, { status: 400 });
  }
  if (String(content).length > 3000) {
    return NextResponse.json({ error: "Comment is too long" }, { status: 400 });
  }

  const article = await db.article.findUnique({ where: { id: articleId } });
  if (!article) {
    return NextResponse.json({ error: "Article not found" }, { status: 404 });
  }

  await db.comment.create({
    data: {
      articleId,
      authorName: String(authorName).slice(0, 200),
      authorEmail: String(authorEmail).slice(0, 200),
      content: String(content).slice(0, 3000),
      approved: false,
    },
  });

  return NextResponse.json({ ok: true }, { status: 201 });
}
