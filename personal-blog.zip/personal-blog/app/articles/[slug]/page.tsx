import { notFound } from "next/navigation";
import Link from "next/link";
import type { Metadata } from "next";
import { getArticleBySlug, getArticlesByCategory, incrementViewCount } from "@/lib/articles";
import { markdownToHtml, formatDate } from "@/lib/utils";
import CommentList from "@/components/articles/CommentList";
import CommentForm from "@/components/articles/CommentForm";

type Props = { params: { slug: string } };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const article = await getArticleBySlug(params.slug);
  if (!article) return {};
  return {
    title: article.title,
    description: article.excerpt ?? undefined,
  };
}

export default async function ArticlePage({ params }: Props) {
  const article = await getArticleBySlug(params.slug);

  if (!article || article.status !== "PUBLISHED") {
    notFound();
  }

  incrementViewCount(article.id).catch(() => {});

  const related = article.categoryId
    ? (await getArticlesByCategory(article.category!.slug))
        .filter((a) => a.slug !== article.slug)
        .slice(0, 3)
    : [];

  return (
    <article className="mx-auto max-w-3xl px-6 py-16">
      <header>
        {article.category && (
          <Link
            href={`/category/${article.category.slug}`}
            className="text-sm text-brass"
          >
            {article.category.name}
          </Link>
        )}
        <h1 className="mt-3 font-serif text-4xl italic leading-tight">
          {article.title}
        </h1>
        <div className="mt-4 flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-light dark:text-muted">
          <span>{article.author.name}</span>
          {article.publishedAt && <span>{formatDate(article.publishedAt)}</span>}
          {article.readingTime && <span>{article.readingTime} min read</span>}
        </div>
      </header>

      {article.featuredImage && (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={article.featuredImage}
          alt=""
          className="mt-8 w-full border border-line-light object-cover dark:border-line"
        />
      )}

      <div
        className="prose prose-lg mt-10 max-w-none"
        dangerouslySetInnerHTML={{ __html: markdownToHtml(article.content) }}
      />

      {article.tags.length > 0 && (
        <div className="mt-10 flex flex-wrap gap-3 border-t border-line-light pt-6 dark:border-line">
          {article.tags.map(({ tag }) => (
            <Link
              key={tag.slug}
              href={`/tag/${tag.slug}`}
              className="text-sm text-muted-light hover:text-brass dark:text-muted"
            >
              #{tag.name}
            </Link>
          ))}
        </div>
      )}

      {related.length > 0 && (
        <section className="mt-14 border-t border-line-light pt-8 dark:border-line">
          <h2 className="font-serif text-xl italic">More in {article.category?.name}</h2>
          <ul className="mt-4 space-y-3">
            {related.map((item) => (
              <li key={item.slug}>
                <Link
                  href={`/articles/${item.slug}`}
                  className="hover:text-brass"
                >
                  {item.title}
                </Link>
              </li>
            ))}
          </ul>
        </section>
      )}

      <section className="mt-14 border-t border-line-light pt-8 dark:border-line">
        <h2 className="font-serif text-xl italic">Comments</h2>
        <div className="mt-6">
          <CommentList comments={article.comments} />
        </div>
        <div className="mt-8">
          <CommentForm articleId={article.id} />
        </div>
      </section>
    </article>
  );
}
