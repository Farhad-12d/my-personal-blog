import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { getArticlesByCategory } from "@/lib/articles";
import ArticleRow from "@/components/articles/ArticleRow";

type Props = { params: { slug: string } };

export async function generateMetadata({ params }: Props) {
  const category = await db.category.findUnique({ where: { slug: params.slug } });
  return { title: category?.name ?? "Category" };
}

export default async function CategoryPage({ params }: Props) {
  const category = await db.category.findUnique({ where: { slug: params.slug } });
  if (!category) notFound();

  const articles = await getArticlesByCategory(params.slug);

  return (
    <div className="mx-auto max-w-5xl px-6 py-16">
      <h1 className="font-serif text-3xl italic">{category.name}</h1>
      {category.description && (
        <p className="mt-3 max-w-xl text-muted-light dark:text-muted">
          {category.description}
        </p>
      )}

      {articles.length === 0 ? (
        <p className="mt-10 text-muted-light dark:text-muted">
          No articles here yet.
        </p>
      ) : (
        <div className="mt-8 divide-y divide-line-light dark:divide-line">
          {articles.map((article) => (
            <ArticleRow key={article.slug} article={article} />
          ))}
        </div>
      )}
    </div>
  );
}
