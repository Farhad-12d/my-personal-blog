import { getPublishedArticles, getCategories } from "@/lib/articles";
import ArticleRow from "@/components/articles/ArticleRow";
import CategoryChip from "@/components/articles/CategoryChip";
import HeroScene from "@/components/3d/HeroScene";

export default async function HomePage() {
  const [articles, categories] = await Promise.all([
    getPublishedArticles(12),
    getCategories(),
  ]);

  return (
    <div className="mx-auto max-w-5xl px-6">
      <section className="grid items-center gap-10 py-16 sm:grid-cols-2 sm:py-24">
        <div>
          <h1 className="font-serif text-4xl italic leading-tight sm:text-5xl">
            Writing things down so I understand them better.
          </h1>
          <p className="mt-6 max-w-md text-muted-light dark:text-muted">
            A running set of essays and shorter notes — mostly about
            physics, building things, and whatever I&apos;m in the middle of
            figuring out.
          </p>
        </div>
        <HeroScene />
      </section>

      <section className="border-t border-line-light py-12 dark:border-line">
        <h2 className="font-serif text-2xl italic">Latest</h2>
        {articles.length === 0 ? (
          <p className="mt-6 text-muted-light dark:text-muted">
            Nothing published yet — the first entry will show up here.
          </p>
        ) : (
          <div className="mt-4 divide-y divide-line-light dark:divide-line">
            {articles.map((article) => (
              <ArticleRow key={article.slug} article={article} />
            ))}
          </div>
        )}
      </section>

      {categories.length > 0 && (
        <section className="border-t border-line-light py-12 dark:border-line">
          <h2 className="font-serif text-2xl italic">Browse by topic</h2>
          <div className="mt-5 flex flex-wrap gap-x-6 gap-y-3">
            {categories.map((category) => (
              <CategoryChip
                key={category.slug}
                name={category.name}
                slug={category.slug}
                count={category._count.articles}
              />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
