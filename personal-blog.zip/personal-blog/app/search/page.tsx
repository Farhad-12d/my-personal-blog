import { searchArticles } from "@/lib/articles";
import ArticleRow from "@/components/articles/ArticleRow";

export const metadata = { title: "Search" };

type Props = { searchParams: { q?: string } };

export default async function SearchPage({ searchParams }: Props) {
  const query = searchParams.q?.trim() ?? "";
  const results = query ? await searchArticles(query) : [];

  return (
    <div className="mx-auto max-w-5xl px-6 py-16">
      <h1 className="font-serif text-3xl italic">Search</h1>

      <form action="/search" className="mt-8">
        <input
          type="search"
          name="q"
          defaultValue={query}
          placeholder="Search articles"
          className="w-full max-w-md border border-line-light bg-transparent px-3 py-2 text-sm outline-none focus:border-brass dark:border-line"
          autoFocus
        />
      </form>

      <div className="mt-10">
        {query === "" ? (
          <p className="text-muted-light dark:text-muted">
            Type something above to search.
          </p>
        ) : results.length === 0 ? (
          <p className="text-muted-light dark:text-muted">
            No articles match &ldquo;{query}&rdquo;.
          </p>
        ) : (
          <div className="divide-y divide-line-light dark:divide-line">
            {results.map((article) => (
              <ArticleRow key={article.slug} article={article} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
