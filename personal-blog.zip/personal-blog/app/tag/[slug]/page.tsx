import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { getArticlesByTag } from "@/lib/articles";
import ArticleRow from "@/components/articles/ArticleRow";

type Props = { params: { slug: string } };

export async function generateMetadata({ params }: Props) {
  const tag = await db.tag.findUnique({ where: { slug: params.slug } });
  return { title: tag ? `#${tag.name}` : "Tag" };
}

export default async function TagPage({ params }: Props) {
  const tag = await db.tag.findUnique({ where: { slug: params.slug } });
  if (!tag) notFound();

  const articles = await getArticlesByTag(params.slug);

  return (
    <div className="mx-auto max-w-5xl px-6 py-16">
      <h1 className="font-serif text-3xl italic">#{tag.name}</h1>

      {articles.length === 0 ? (
        <p className="mt-10 text-muted-light dark:text-muted">
          No articles tagged yet.
        </p>
      ) : (
        <div className="mt-8 divide-y divide-line-light dark:divide-line">
          {articles.map((article) => (
            <ArticleRow key={article.slug} article={article} />
          ))}
        </div>
      )}
    </div>
  );
}
