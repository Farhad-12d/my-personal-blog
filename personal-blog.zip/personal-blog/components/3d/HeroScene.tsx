"use client";

import dynamic from "next/dynamic";

// The WebGL canvas only ever runs client-side, and is lazy-loaded so it
// never blocks the initial page render or the article-reading path.
const OrbitScene = dynamic(() => import("./OrbitScene"), {
  ssr: false,
  loading: () => <div className="h-full w-full" aria-hidden />,
});

export default function HeroScene() {
  return (
    <div
      className="pointer-events-none aspect-square w-full max-w-sm"
      aria-hidden="true"
    >
      <OrbitScene />
    </div>
  );
}
