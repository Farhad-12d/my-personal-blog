"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Button from "@/components/ui/Button";
import { markdownToHtml, slugify } from "@/lib/utils";

type Category = { id: string; name: string };

type ArticleData = {
  id?: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  featuredImage: string;
  status: "DRAFT" | "PUBLISHED" | "SCHEDULED" | "ARCHIVED";
  categoryId: string;
  tagNames: string;
};

const emptyArticle: ArticleData = {
  title: "",
  slug: "",
  excerpt: "",
  content: "",
  featuredImage: "",
  status: "DRAFT",
  categoryId: "",
  tagNames: "",
};

export default function ArticleEditor({
  categories,
  initial,
}: {
  categories: Category[];
  initial?: Partial<ArticleData>;
}) {
  const router = useRouter();
  const [article, setArticle] = useState<ArticleData>({ ...emptyArticle, ...initial });
  const [slugTouched, setSlugTouched] = useState(Boolean(initial?.slug));
  const [showPreview, setShowPreview] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  function update<K extends keyof ArticleData>(key: K, value: ArticleData[K]) {
    setArticle((prev) => ({ ...prev, [key]: value }));
  }

  function handleTitleChange(value: string) {
    update("title", value);
    if (!slugTouched) update("slug", slugify(value));
  }

  async function save(status: ArticleData["status"]) {
    setSaving(true);
    setError("");

    const payload = {
      title: article.title,
      slug: article.slug,
      excerpt: article.excerpt,
      content: article.content,
      featuredImage: article.featuredImage || undefined,
      status,
      categoryId: article.categoryId || null,
      tagNames: article.tagNames
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean),
    };

    const url = article.id ? `/api/articles/${article.id}` : "/api/articles";
    const method = article.id ? "PATCH" : "POST";

    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (res.ok) {
      router.push("/admin/articles");
      router.refresh();
    } else {
      const body = await res.json().catch(() => ({}));
      setError(body.error || "Couldn't save. Try again.");
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      <input
        value={article.title}
        onChange={(e) => handleTitleChange(e.target.value)}
        placeholder="Title"
        className="w-full border-b border-line-light bg-transparent py-2 font-serif text-2xl italic outline-none focus:border-brass dark:border-line"
      />

      <div className="grid gap-4 sm:grid-cols-2">
        <label className="text-sm">
          Slug
          <input
            value={article.slug}
            onChange={(e) => {
              setSlugTouched(true);
              update("slug", e.target.value);
            }}
            className="mt-1 w-full border border-line-light bg-transparent px-3 py-2 text-sm outline-none focus:border-brass dark:border-line"
          />
        </label>
        <label className="text-sm">
          Category
          <select
            value={article.categoryId}
            onChange={(e) => update("categoryId", e.target.value)}
            className="mt-1 w-full border border-line-light bg-transparent px-3 py-2 text-sm outline-none focus:border-brass dark:border-line"
          >
            <option value="">None</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </label>
      </div>

      <label className="block text-sm">
        Excerpt
        <textarea
          value={article.excerpt}
          onChange={(e) => update("excerpt", e.target.value)}
          rows={2}
          className="mt-1 w-full border border-line-light bg-transparent px-3 py-2 text-sm outline-none focus:border-brass dark:border-line"
        />
      </label>

      <label className="block text-sm">
        Featured image URL
        <input
          value={article.featuredImage}
          onChange={(e) => update("featuredImage", e.target.value)}
          placeholder="https://…"
          className="mt-1 w-full border border-line-light bg-transparent px-3 py-2 text-sm outline-none focus:border-brass dark:border-line"
        />
      </label>

      <label className="block text-sm">
        Tags (comma separated)
        <input
          value={article.tagNames}
          onChange={(e) => update("tagNames", e.target.value)}
          placeholder="physics, notes"
          className="mt-1 w-full border border-line-light bg-transparent px-3 py-2 text-sm outline-none focus:border-brass dark:border-line"
        />
      </label>

      <div>
        <div className="flex items-center justify-between text-sm">
          <span>Content (Markdown)</span>
          <button
            type="button"
            onClick={() => setShowPreview((p) => !p)}
            className="text-brass hover:underline"
          >
            {showPreview ? "Edit" : "Preview"}
          </button>
        </div>
        {showPreview ? (
          <div
            className="prose prose-lg mt-2 max-w-none border border-line-light p-4 dark:border-line"
            dangerouslySetInnerHTML={{ __html: markdownToHtml(article.content || "*Nothing yet*") }}
          />
        ) : (
          <textarea
            value={article.content}
            onChange={(e) => update("content", e.target.value)}
            rows={16}
            placeholder="# Title&#10;&#10;Write in Markdown…"
            className="mt-2 w-full border border-line-light bg-transparent px-3 py-2 font-serif text-base outline-none focus:border-brass dark:border-line"
          />
        )}
      </div>

      {error && <p className="text-sm text-red-400">{error}</p>}

      <div className="flex gap-3 border-t border-line-light pt-6 dark:border-line">
        <Button variant="ghost" disabled={saving} onClick={() => save("DRAFT")}>
          Save draft
        </Button>
        <Button disabled={saving} onClick={() => save("PUBLISHED")}>
          {saving ? "Saving…" : "Publish"}
        </Button>
      </div>
    </div>
  );
}
