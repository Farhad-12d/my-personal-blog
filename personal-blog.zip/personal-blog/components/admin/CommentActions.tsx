"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export default function CommentActions({
  id,
  approved,
}: {
  id: string;
  approved: boolean;
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function toggleApproved() {
    setBusy(true);
    const res = await fetch(`/api/comments/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ approved: !approved }),
    });
    setBusy(false);
    if (res.ok) router.refresh();
  }

  async function handleDelete() {
    if (!confirm("Delete this comment?")) return;
    setBusy(true);
    const res = await fetch(`/api/comments/${id}`, { method: "DELETE" });
    setBusy(false);
    if (res.ok) router.refresh();
  }

  return (
    <div className="flex shrink-0 items-center gap-4 text-sm">
      <button onClick={toggleApproved} disabled={busy} className="hover:text-brass disabled:opacity-50">
        {approved ? "Unapprove" : "Approve"}
      </button>
      <button onClick={handleDelete} disabled={busy} className="text-red-400 hover:underline disabled:opacity-50">
        Delete
      </button>
    </div>
  );
}
