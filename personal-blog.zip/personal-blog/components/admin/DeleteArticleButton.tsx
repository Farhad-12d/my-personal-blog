"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export default function DeleteArticleButton({ id, title }: { id: string; title: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function handleDelete() {
    if (!confirm(`Delete "${title}"? This can't be undone.`)) return;
    setBusy(true);
    const res = await fetch(`/api/articles/${id}`, { method: "DELETE" });
    if (res.ok) {
      router.refresh();
    } else {
      setBusy(false);
      alert("Couldn't delete. Try again.");
    }
  }

  return (
    <button
      onClick={handleDelete}
      disabled={busy}
      className="text-sm text-red-400 hover:underline disabled:opacity-50"
    >
      Delete
    </button>
  );
}
