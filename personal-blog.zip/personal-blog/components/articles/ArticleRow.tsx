import Link from "next/link";
import { formatDate } from "@/lib/utils";

type ArticleRowProps = {
  article: {
    slug: string;
    title: string;
    excerpt: string | null;
    publishedAt: Date | string | null;
    readingTime: number | null;
    category: { name: string; slug: string } | null;
  };
};

export default function ArticleRow({ article }: ArticleRowProps) {
  return (
    <Link
      href={`/articles/${article.slug}`}
      className="group grid gap-1 py-6 sm:grid-cols-[9rem_1fr] sm:gap-6"
    >
      <div className="text-sm text-muted-light dark:text-muted">
        {article.publishedAt && (
          <time>{formatDate(article.publishedAt)}</time>
        )}
        {article.category && (
          <div className="mt-1">{article.category.name}</div>
        )}
      </div>

      <div>
        <h3 className="font-serif text-xl text-ink-light transition-colors group-hover:text-brass dark:text-paper">
          {article.title}
        </h3>
        {article.excerpt && (
          <p className="mt-2 max-w-xl text-sm text-muted-light dark:text-muted">
            {article.excerpt}
          </p>
        )}
        {article.readingTime && (
          <p className="mt-2 text-xs text-muted-light dark:text-muted">
            {article.readingTime} min read
          </p>
        )}
      </div>
    </Link>
  );
}
