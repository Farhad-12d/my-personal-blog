import Link from "next/link";

export default function CategoryChip({
  name,
  slug,
  count,
}: {
  name: string;
  slug: string;
  count?: number;
}) {
  return (
    <Link
      href={`/category/${slug}`}
      className="border-b border-transparent text-sm transition-colors hover:border-brass hover:text-brass"
    >
      {name}
      {typeof count === "number" && (
        <span className="text-muted-light dark:text-muted"> ({count})</span>
      )}
    </Link>
  );
}
