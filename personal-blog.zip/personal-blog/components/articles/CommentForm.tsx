"use client";

import { useState, FormEvent } from "react";
import Button from "@/components/ui/Button";

export default function CommentForm({ articleId }: { articleId: string }) {
  const [status, setStatus] = useState<"idle" | "submitting" | "done" | "error">("idle");
  const [error, setError] = useState("");

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("submitting");
    setError("");

    const form = event.currentTarget;
    const data = new FormData(form);

    const res = await fetch("/api/comments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        articleId,
        authorName: data.get("authorName"),
        authorEmail: data.get("authorEmail"),
        content: data.get("content"),
      }),
    });

    if (res.ok) {
      setStatus("done");
      form.reset();
    } else {
      const body = await res.json().catch(() => ({}));
      setError(body.error || "Something went wrong. Try again.");
      setStatus("error");
    }
  }

  if (status === "done") {
    return (
      <p className="text-sm text-muted-light dark:text-muted">
        Thanks — your comment is in for review and will appear once approved.
      </p>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <input
          name="authorName"
          required
          placeholder="Name"
          className="border border-line-light bg-transparent px-3 py-2 text-sm outline-none focus:border-brass dark:border-line"
        />
        <input
          name="authorEmail"
          type="email"
          required
          placeholder="Email (not published)"
          className="border border-line-light bg-transparent px-3 py-2 text-sm outline-none focus:border-brass dark:border-line"
        />
      </div>
      <textarea
        name="content"
        required
        rows={4}
        placeholder="Add to the discussion"
        className="w-full border border-line-light bg-transparent px-3 py-2 text-sm outline-none focus:border-brass dark:border-line"
      />
      {error && <p className="text-sm text-red-400">{error}</p>}
      <Button type="submit" disabled={status === "submitting"}>
        {status === "submitting" ? "Sending…" : "Add comment"}
      </Button>
    </form>
  );
}
