import { formatDate } from "@/lib/utils";

type CommentListProps = {
  comments: {
    id: string;
    authorName: string;
    content: string;
    createdAt: Date | string;
  }[];
};

export default function CommentList({ comments }: CommentListProps) {
  if (comments.length === 0) {
    return (
      <p className="text-sm text-muted-light dark:text-muted">
        No comments yet.
      </p>
    );
  }

  return (
    <ul className="space-y-6">
      {comments.map((comment) => (
        <li key={comment.id} className="border-t border-line-light pt-4 dark:border-line">
          <p className="text-sm">
            <span className="font-medium">{comment.authorName}</span>{" "}
            <span className="text-muted-light dark:text-muted">
              {formatDate(comment.createdAt)}
            </span>
          </p>
          <p className="mt-2 text-sm text-muted-light dark:text-muted">
            {comment.content}
          </p>
        </li>
      ))}
    </ul>
  );
}
