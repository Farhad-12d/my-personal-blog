export default function Footer() {
  return (
    <footer className="border-t border-line-light dark:border-line">
      <div className="mx-auto flex max-w-5xl flex-col gap-2 px-6 py-8 text-sm text-muted-light dark:text-muted sm:flex-row sm:items-center sm:justify-between">
        <p>© {new Date().getFullYear()} Field Notes.</p>
        <p>Built with Next.js, deployed on Netlify.</p>
      </div>
    </footer>
  );
}
