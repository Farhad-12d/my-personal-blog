import Link from "next/link";
import ThemeToggle from "@/components/ui/ThemeToggle";

export default function Navbar() {
  return (
    <header className="border-b border-line-light dark:border-line">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-5">
        <Link
          href="/"
          className="font-serif text-lg italic tracking-tight text-ink-light dark:text-paper"
        >
          Field Notes
        </Link>

        <nav className="flex items-center gap-6 text-sm">
          <Link href="/" className="transition-colors hover:text-brass">
            Essays
          </Link>
          <Link href="/about" className="transition-colors hover:text-brass">
            About
          </Link>
          <Link
            href="/search"
            aria-label="Search"
            className="transition-colors hover:text-brass"
          >
            Search
          </Link>
          <ThemeToggle />
        </nav>
      </div>
    </header>
  );
}
