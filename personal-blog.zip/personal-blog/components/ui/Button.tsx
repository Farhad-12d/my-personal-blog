import { ButtonHTMLAttributes } from "react";

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "ghost" | "danger";
};

const variants: Record<string, string> = {
  primary: "bg-brass text-ink hover:bg-brass/90",
  ghost:
    "border border-line-light text-ink-light hover:border-brass hover:text-brass dark:border-line dark:text-paper",
  danger: "border border-red-800 text-red-400 hover:bg-red-950",
};

export default function Button({
  variant = "primary",
  className = "",
  ...props
}: ButtonProps) {
  return (
    <button
      className={`inline-flex items-center justify-center rounded px-4 py-2 text-sm font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-50 ${variants[variant]} ${className}`}
      {...props}
    />
  );
}
