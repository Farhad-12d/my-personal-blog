import { db } from "@/lib/db";
import { slugify, estimateReadingTime } from "@/lib/utils";

type ArticleInput = {
  title: string;
  slug?: string;
  excerpt?: string;
  content: string;
  featuredImage?: string;
  status: "DRAFT" | "PUBLISHED" | "SCHEDULED" | "ARCHIVED";
  publishedAt?: string | null;
  categoryId?: string | null;
  tagNames?: string[];
  authorId: string;
};

async function uniqueSlug(base: string, ignoreId?: string) {
  let slug = slugify(base) || `article-${Date.now()}`;
  let suffix = 1;
  // eslint-disable-next-line no-constant-condition
  while (true) {
    const existing = await db.article.findUnique({ where: { slug } });
    if (!existing || existing.id === ignoreId) return slug;
    suffix += 1;
    slug = `${slugify(base)}-${suffix}`;
  }
}

async function resolveTagIds(tagNames: string[] = []) {
  const ids: string[] = [];
  for (const raw of tagNames) {
    const name = raw.trim();
    if (!name) continue;
    const slug = slugify(name);
    const tag = await db.tag.upsert({
      where: { slug },
      update: {},
      create: { name, slug },
    });
    ids.push(tag.id);
  }
  return ids;
}

export async function createArticle(input: ArticleInput) {
  const slug = await uniqueSlug(input.slug || input.title);
  const tagIds = await resolveTagIds(input.tagNames);

  return db.article.create({
    data: {
      title: input.title,
      slug,
      excerpt: input.excerpt,
      content: input.content,
      featuredImage: input.featuredImage,
      status: input.status,
      publishedAt:
        input.status === "PUBLISHED"
          ? input.publishedAt
            ? new Date(input.publishedAt)
            : new Date()
          : input.publishedAt
          ? new Date(input.publishedAt)
          : null,
      readingTime: estimateReadingTime(input.content),
      authorId: input.authorId,
      categoryId: input.categoryId || null,
      tags: { create: tagIds.map((tagId) => ({ tagId })) },
    },
  });
}

export async function updateArticle(id: string, input: Partial<ArticleInput>) {
  const data: Record<string, unknown> = {};

  if (input.title) data.title = input.title;
  if (input.slug) data.slug = await uniqueSlug(input.slug, id);
  if (input.excerpt !== undefined) data.excerpt = input.excerpt;
  if (input.content) {
    data.content = input.content;
    data.readingTime = estimateReadingTime(input.content);
  }
  if (input.featuredImage !== undefined) data.featuredImage = input.featuredImage;
  if (input.status) {
    data.status = input.status;
    if (input.status === "PUBLISHED") {
      const existing = await db.article.findUnique({ where: { id }, select: { publishedAt: true } });
      data.publishedAt = existing?.publishedAt ?? new Date();
    }
  }
  if (input.publishedAt !== undefined) {
    data.publishedAt = input.publishedAt ? new Date(input.publishedAt) : null;
  }
  if (input.categoryId !== undefined) data.categoryId = input.categoryId || null;

  if (input.tagNames) {
    const tagIds = await resolveTagIds(input.tagNames);
    await db.articleTag.deleteMany({ where: { articleId: id } });
    data.tags = { create: tagIds.map((tagId) => ({ tagId })) };
  }

  return db.article.update({ where: { id }, data });
}

export async function deleteArticle(id: string) {
  return db.article.delete({ where: { id } });
}

const publishedListSelect = {
  id: true,
  title: true,
  slug: true,
  excerpt: true,
  publishedAt: true,
  readingTime: true,
  category: { select: { name: true, slug: true } },
} as const;

export async function getPublishedArticles(limit?: number) {
  return db.article.findMany({
    where: { status: "PUBLISHED" },
    orderBy: { publishedAt: "desc" },
    take: limit,
    select: publishedListSelect,
  });
}

export async function getArticleBySlug(slug: string) {
  return db.article.findUnique({
    where: { slug },
    include: {
      author: { select: { name: true, bio: true, avatar: true } },
      category: { select: { name: true, slug: true } },
      tags: { include: { tag: true } },
      comments: {
        where: { approved: true },
        orderBy: { createdAt: "desc" },
      },
    },
  });
}

export async function getArticlesByCategory(slug: string) {
  return db.article.findMany({
    where: { status: "PUBLISHED", category: { slug } },
    orderBy: { publishedAt: "desc" },
    select: publishedListSelect,
  });
}

export async function getArticlesByTag(slug: string) {
  return db.article.findMany({
    where: { status: "PUBLISHED", tags: { some: { tag: { slug } } } },
    orderBy: { publishedAt: "desc" },
    select: publishedListSelect,
  });
}

export async function searchArticles(query: string) {
  if (!query.trim()) return [];
  return db.article.findMany({
    where: {
      status: "PUBLISHED",
      OR: [
        { title: { contains: query, mode: "insensitive" } },
        { excerpt: { contains: query, mode: "insensitive" } },
        { content: { contains: query, mode: "insensitive" } },
      ],
    },
    orderBy: { publishedAt: "desc" },
    select: publishedListSelect,
  });
}

export async function getCategories() {
  return db.category.findMany({
    orderBy: { name: "asc" },
    include: { _count: { select: { articles: true } } },
  });
}

export async function getAllTags() {
  return db.tag.findMany({ orderBy: { name: "asc" } });
}

export async function incrementViewCount(id: string) {
  await db.article.update({
    where: { id },
    data: { viewCount: { increment: 1 } },
  });
}
