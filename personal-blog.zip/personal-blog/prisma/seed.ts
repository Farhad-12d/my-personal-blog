import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const email = process.env.ADMIN_EMAIL || "you@example.com";
  const password = process.env.ADMIN_PASSWORD || "changeme123";
  const hashed = await bcrypt.hash(password, 10);

  const user = await prisma.user.upsert({
    where: { email },
    update: {},
    create: {
      name: process.env.ADMIN_NAME || "Admin",
      email,
      password: hashed,
      bio: "Writer and builder.",
    },
  });

  const category = await prisma.category.upsert({
    where: { slug: "notes" },
    update: {},
    create: {
      name: "Notes",
      slug: "notes",
      description: "Short-form thoughts and observations.",
    },
  });

  await prisma.article.upsert({
    where: { slug: "hello-world" },
    update: {},
    create: {
      title: "Hello, world",
      slug: "hello-world",
      excerpt: "The first entry. A short note on starting somewhere.",
      content:
        "# Hello, world\n\nThis is the first article on the site. Edit or delete it from `/admin/articles`, and start writing your own.\n\nMarkdown is supported: **bold**, *italic*, `code`, [links](/), and\n\n> blockquotes\n\nwork as expected.",
      status: "PUBLISHED",
      publishedAt: new Date(),
      readingTime: 1,
      authorId: user.id,
      categoryId: category.id,
    },
  });

  console.log(`Seeded admin user: ${email} / ${password}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
